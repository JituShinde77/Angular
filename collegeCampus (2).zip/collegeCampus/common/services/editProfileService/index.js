angular.module('editProfile.services',['editProfile.service'] );
