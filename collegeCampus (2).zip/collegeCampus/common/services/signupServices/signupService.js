angular.module('signup.service',[])
       .factory('signupService',[
      '$http',
       '$cookies',
       '$rootScope',
       '$sessionStorage',
       function($http, $cookies, $rootScope, $sessionStorage) {

         var service = {};
         service.validate = Validate;
         return service;

        function Validate(email,password, full_name, confirm_password, phone_number ) {
            
            var payload = "email=" + email + "&password=" + password + "&full_name=" + full_name + "&source=" + "WEB_APP" + "&confirm_password=" + confirm_password + "&phone_number=" + phone_number;
            
            var url =  $http.post($rootScope.endPoint + '/api/user/register/', payload);
            return url;

         

        };

}]);

//http://127.0.0.1/api/user/register/
    //     "email":"ganesh35palkar@gmail.com",
    // "password":"ganesh123456",
    // "full_name": "ganesh palkar",
    // "source":"WEB_APP",
    // "confirm_password":"ganesh123456",
    // "phone_number":"8308266923"