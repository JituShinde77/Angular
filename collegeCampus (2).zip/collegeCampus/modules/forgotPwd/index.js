'use strict';

angular.module('forgotPwd', 
	['forgotPwd.controller'])
    .config(
    ['$stateProvider',
     '$urlRouterProvider',
     '$httpProvider',
     function($stateProvider, $urlRouterProvider, $httpProvider) {

            $urlRouterProvider.otherwise('/');
       
            $urlRouterProvider.when('home', '/home');

            $stateProvider
            .state('forgotPwd', {
            url: '/forgoPwd',
            templateUrl: 'modules/forgotPwd/views/forgotPwd.html',
            controller: 'forgotPwdCtrl',
            label: 'forgotPwd',
        })
         }
       ]);