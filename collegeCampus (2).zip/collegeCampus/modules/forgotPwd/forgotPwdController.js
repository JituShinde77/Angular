angular.module('forgotPwd.controller', ['forgotPwd.services'])
    .controller('forgotPwdCtrl', ['$scope',
      'forgotPwdService' ,
      '$http', 
      '$state', 
      function($scope, forgotPwdService, $http, $state) {
   	
   	 document.getElementById("emailid").focus();
    $scope.user = {};
    $scope.authError = null;

    $scope.sendEmail = function() {

    	$scope.authError = null;  

         var email="shindejitu77@gmail.com";
         var subject = "Test Email";
         var body="success";
       		var link = "mailto:"+ "shindejitu77@gmail.com"
             + "?subject=New%20email " + escape("Test")
             + "&body=" + escape("success"); 

    		window.location.href = link;
 		  // var response = forgotPwdService.validate($scope.email );
         // response.then(function success(response) {
         //                if (response.data  && ! response.data.error) {
         //                    var access_token = response.data.access_token;
         //                    $sessionStorage.access_token = access_token;
         //                    $scope.authError = "Login SUCCESS!!!"
         //                    console.log(response.data);
         //                } else {
         //                    $scope.isInvalid = true;
         //                    $scope.authError = "Username and Password do not match !!!"
         //                    console.log(response);
         //                }
         //            }, function error(response) {
         //                $scope.isInvalid = true;
         //                if(response.data.email)
         //              {
         //                document.getElementById("emailid").focus();
                                                 
         //                 alert("Ok, please check your email address.");
         //              }
         //              else
         //              {
         //              	alert("Email does not found.");
         //                  $scope.authError = "Email Field Must be Unique.";
         //                  $scope.authError= "Email not found."; 
         //              }
         //              debugger;

         //                $scope.authError= "Email is Valid";
         //                console.log(response);
         //            })
    }

    


  }])
 ;