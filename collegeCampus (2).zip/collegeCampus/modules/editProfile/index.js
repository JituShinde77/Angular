'use strict';

angular.module('editProfile', ['editProfile.controller'])
.config(
    [
    '$stateProvider',
     '$urlRouterProvider',
     '$httpProvider',
     function($stateProvider, $urlRouterProvider, $httpProvider) {

            $urlRouterProvider.otherwise('/');
       
            $urlRouterProvider.when('login', '/login');
            $stateProvider.state('app', 
            {
            	url: '/app',
	            templateUrl: 'common/view/app.html',
	            label: 'app1',
            })

            .state('app.editProfile', {
                  url: '/editProfile',
                  templateUrl: 'modules/editProfile/views/editProfile.html',
                  controller : 'editProfileCtrl', 
                  label : 'editProfile1',
                  //resolve: load(['modules/editProfile/editProfileCtrl.js'])
              })
         }
       ]);

    