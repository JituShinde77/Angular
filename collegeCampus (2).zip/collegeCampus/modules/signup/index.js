'use strict';

angular.module('signup', [
    'signup.controller'
]).config(
    ['$stateProvider',
     '$urlRouterProvider',
     '$httpProvider',
     function($stateProvider, $urlRouterProvider, $httpProvider) {

            $urlRouterProvider.otherwise('/');
       
            //$urlRouterProvider.when('login', '/login');
            $urlRouterProvider.when('Home', '/home');
            $stateProvider
            .state('signup', {
            url: '/signup',
            templateUrl: 'modules/signup/views/signup.html',
            controller: 'signupCtrl',
            label: 'SignUp',
            })
         }
       ]);


    //     $urlRouterProvider.otherwise('/');
    //     $urlRouterProvider.when('header.home', '/header.home');
        
    //     .state('header.home', {
    //         url: '',
    //         cache: false,
    //         templateUrl: '/static/modules/dashboard/views/dashboard.html',
    //         controller: 'dashboardCtrl',
    //         label: 'Home',
    //     })
    // }]);