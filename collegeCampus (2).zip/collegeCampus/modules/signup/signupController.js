angular.module('signup.controller', ['signup.services'])
    .controller('signupCtrl', ['$scope',
      '$log',
      'signupService' , 
      '$state', 
      '$sessionStorage', 
      '$timeout',
      function($scope, $log ,signupService,  $state, $sessionStorage, $timeout) {
    $scope.user = {};
    $scope.authError = null;
    $scope.signup = function() {
      $scope.authError = null;
      // Try to create
         var response = signupService.validate( $scope.user.email,
          $scope.user.password, $scope.user.full_name,  
          $scope.user.confirm_password,$scope.user.phone_number );
         response.then(function success(response) {
                        if (response.data.success == "true" ) {
                            var access_token = response.data.access_token;
                            $sessionStorage.access_token = access_token;
                            $scope.authError = response.data.msg;
                            console.log(response.data);
                        }
                        else if(response.data.email)
                        {
                          $scope.authError = response.data.email[0];
                        }
                        else if(response.data.msg== "password length min 8 char.")
                            $scope.authError = "Password Incorrect Please Enter in the requited format!!!"
   
                        else {
                            $scope.isInvalid = true;
                            $scope.authError = "Username and Password do not match !!!"
                            console.log(response);
                        }
                    }, 
                    function error(response) {
                      if(response.status == 404)
                        {
                          $state.go('404');
                        }
                      if(response.data.email)
                      {

                        document.getElementById("emailid").focus();
                         $scope.authError = "Email Field Must be Unique.";                        
                      }
                      else
                      {
                          $scope.authError= "Wrong Data"; 
                      }
                      debugger;
                        $scope.isInvalid = true;
                       //$scope.authError = response.data.email[0];
                        console.log(response);
                    })
         

    };
  }])
 ;