'use strict';

angular.module('login', ['login.controller'])
