angular.module('login.controller', ['login.services'])
      .controller('loginCtrl', [ 
      '$scope','loginService', '$state', '$sessionStorage', '$timeout',
      
      function($scope,loginService , $state, $sessionStorage, $timeout) {
  
      $scope.user = {};
       $scope.authError = null;
       $scope.login = function() {
        $scope.authError = null;  
         var response = loginService.validate($scope.user.email, $scope.user.password);
         response.then(function success(response) {
                        if (response.data  && ! response.data.error) {
                            var access_token = response.data.access_token;
                            $sessionStorage.access_token = access_token;
                            $scope.authError = "Login SUCCESS!!!"
                            console.log(response.data);
                            $state.go('app.editProfile');
                        } else {
                            $scope.isInvalid = true;
                            $scope.authError = "Username and Password do not match !!!"
                            console.log(response);
                        }
                    }, function error(response) {
                        $scope.isInvalid = true;
                        $scope.messsage = "Username and Password do not match !!!";
                        $scope.authError= "Username and Password do not match !!!";
                         $state.go('app.editProfile')
                        console.log(response);
                    })

      // Try to login
      // $http.post('api/login', {email: $scope.user.email, password: $scope.user.password})
      // .then(function(response) {
      //   if ( !response.data.user ) {
      //     $scope.authError = 'Email or Password not right';
      //   }else{
      //     $state.go('app.dashboard-v1');
      //   }
      // }, function(x) {
      //   $scope.authError = 'Server Error';
      // });
    };
  }]);
