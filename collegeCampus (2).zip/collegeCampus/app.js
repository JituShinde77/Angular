'use strict';
angular.module('app', [


    'ui.router',
    'ngStorage',
    'editProfile',
    'login',
    'signup',
    'forgotPwd',
    'ngCookies'

]).config(
    ['$stateProvider',
     '$urlRouterProvider',
     '$httpProvider',
     function($stateProvider, $urlRouterProvider, $httpProvider) {

        $urlRouterProvider.otherwise('/');
         $stateProvider.state('login', {
             url: '/',
             templateUrl: 'modules/auth/views/login.html',
             controller: 'loginCtrl',
             label: 'Home',
         })
        
        .state('404', {
                  url: '/404',
                  templateUrl: 'modules/errorPage/views/error_404.html'
              })

    }]).run(['$http', '$cookies', '$rootScope', '$sessionStorage', '$state',
    function($http, $cookies, $rootScope, $sessionStorage, $state ) {
    //Initializing csrf token for all pages in this app.
  
     $http.defaults.headers.post['X-CSRFToken'] = $cookies.csrftoken;
    $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
    //Adding manual token for now, awaiting implementation via backend
    $rootScope.endPoint = "http://192.168.0.3";
     $state.go('login');
    }
]);
